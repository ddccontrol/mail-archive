ddccontrol version 0.4.2
Copyright 2004-2005 Oleg I. Vdovikin (oleg@cs.msu.su)
Copyright 2004-2006 Nicolas Boichat (nicolas@boichat.ch)
This program comes with ABSOLUTELY NO WARRANTY.
You may redistribute copies of this program under the terms of the GNU General Public License.

ddcpci initing...
Starting /usr/local/bin/ddcpci 1 -1207615672 &...
Probing for available monitors...
Found PCI device (pci:00:01.0-0)
Found PCI device (pci:00:01.0-1)
Found PCI device (pci:00:01.0-2)
Found PCI device (pci:00:01.0-3)
Found PCI device (pci:00:01.0-4)
Found PCI device (pci:00:01.0-5)
Device: pci:00:01.0-0
Control brightness has been discarded by the caps string.
Control contrast has been discarded by the caps string.
Control red has been discarded by the caps string.
Control green has been discarded by the caps string.
Control blue has been discarded by the caps string.
Control redblack has been discarded by the caps string.
Control greenblack has been discarded by the caps string.
Control blueblack has been discarded by the caps string.
Control colortemp has been discarded by the caps string.
Control hpos has been discarded by the caps string.
Control vpos has been discarded by the caps string.
Control hsize has been discarded by the caps string.
Control vsize has been discarded by the caps string.
Control auto has been discarded by the caps string.
Control hpincushion has been discarded by the caps string.
Control hpincushionbalance has been discarded by the caps string.
Control vlinearity has been discarded by the caps string.
Control vlinearitybalance has been discarded by the caps string.
Control hmisconvergence has been discarded by the caps string.
Control vmisconvergence has been discarded by the caps string.
Control keybalance has been discarded by the caps string.
Control key has been discarded by the caps string.
Control tdistortionctrl has been discarded by the caps string.
Control tdistortionbalance has been discarded by the caps string.
Control bdistortionctrl has been discarded by the caps string.
Control bdistortionbalance has been discarded by the caps string.
Control tilt has been discarded by the caps string.
Control hmoire has been discarded by the caps string.
Control vmoire has been discarded by the caps string.
Control focus has been discarded by the caps string.
Control coarse has been discarded by the caps string.
Control fine has been discarded by the caps string.
Control defaults has been discarded by the caps string.
Control defaultluma has been discarded by the caps string.
Control defaultgeom has been discarded by the caps string.
Control defaultcolor has been discarded by the caps string.
Control settings has been discarded by the caps string.
Control audiospeakervolume has been discarded by the caps string.
Control degauss has been discarded by the caps string.
Control osdorientation has been discarded by the caps string.
Control inputsource has been discarded by the caps string.
Control dpms has been discarded by the caps string.
Control power has been discarded by the caps string.
ddcci_open returned 0
Device: pci:00:01.0-1
ddcci_open returned -2
Device: pci:00:01.0-2
ddcci_open returned -2
Device: pci:00:01.0-3
ddcci_open returned -2
Device: pci:00:01.0-4
ddcci_open returned -2
Device: pci:00:01.0-5
ddcci_open returned -2
Detected monitors :
 - Device: pci:00:01.0-0
   DDC/CI supported: Yes
   Monitor Name: VESA standard monitor
   Input type: Analog
  (Automatically selected)
Reading EDID and initializing DDC/CI at bus pci:00:01.0-0...
Device: pci:00:01.0-0
Serial number: 16843009
Manufactured: Week 0, 2000
EDID version: 1.1
Maximum size: 33 x 25 (cm)
Control brightness has been discarded by the caps string.
Control contrast has been discarded by the caps string.
Control red has been discarded by the caps string.
Control green has been discarded by the caps string.
Control blue has been discarded by the caps string.
Control redblack has been discarded by the caps string.
Control greenblack has been discarded by the caps string.
Control blueblack has been discarded by the caps string.
Control colortemp has been discarded by the caps string.
Control hpos has been discarded by the caps string.
Control vpos has been discarded by the caps string.
Control hsize has been discarded by the caps string.
Control vsize has been discarded by the caps string.
Control auto has been discarded by the caps string.
Control hpincushion has been discarded by the caps string.
Control hpincushi810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
==>ddcpci is quitting.
ionbalance has been discarded by the caps string.
Control vlinearity has been discarded by the caps string.
Control vlinearitybalance has been discarded by the caps string.
Control hmisconvergence has been discarded by the caps string.
Control vmisconvergence has been discarded by the caps string.
Control keybalance has been discarded by the caps string.
Control key has been discarded by the caps string.
Control tdistortionctrl has been discarded by the caps string.
Control tdistortionbalance has been discarded by the caps string.
Control bdistortionctrl has been discarded by the caps string.
Control bdistortionbalance has been discarded by the caps string.
Control tilt has been discarded by the caps string.
Control hmoire has been discarded by the caps string.
Control vmoire has been discarded by the caps string.
Control focus has been discarded by the caps string.
Control coarse has been discarded by the caps string.
Control fine has been discarded by the caps string.
Control defaults has been discarded by the caps string.
Control defaultluma has been discarded by the caps string.
Control defaultgeom has been discarded by the caps string.
Control defaultcolor has been discarded by the caps string.
Control settings has been discarded by the caps string.
Control audiospeakervolume has been discarded by the caps string.
Control degauss has been discarded by the caps string.
Control osdorientation has been discarded by the caps string.
Control inputsource has been discarded by the caps string.
Control dpms has been discarded by the caps string.
Control power has been discarded by the caps string.

EDID readings:
	Plug and Play ID: GSM42DC [VESA standard monitor]
	Input type: Analog
=============================== WARNING ===============================
There is no support for your monitor in the database, but ddccontrol is
using a basic generic profile. Many controls will not be supported, and
some controls may not work as expected.
Please update ddccontrol-db, or, if you are already using the latest
version, please send the output of the following command to
ddccontrol-users@lists.sourceforge.net:

LANG= LC_ALL= ddccontrol -p -c -d

Thank you.
=============================== WARNING ===============================

Capabilities:

Controls (valid/current/max) [Description - Value name]:
Control 0x20: +/77/255   [???]
Control 0x22: +/177/255   [???]
Control 0x24: +/21/63   [???]
Control 0x30: +/68/127   [???]
Control 0x32: +/64/127   [???]
Control 0x42: +/36/63   [???]
ddcpci being released...
