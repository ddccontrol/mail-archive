ddccontrol version 0.4.2
Copyright 2004-2005 Oleg I. Vdovikin (oleg@cs.msu.su)
Copyright 2004-2006 Nicolas Boichat (nicolas@boichat.ch)
This program comes with ABSOLUTELY NO WARRANTY.
You may redistribute copies of this program under the terms of the GNU General Public License.

ddcpci initing...
Starting /usr/local/bin/ddcpci 1 235224904 &...
Probing for available monitors...
Found PCI device (pci:00:01.0-0)
Found PCI device (pci:00:01.0-1)
Found PCI device (pci:00:01.0-2)
Found PCI device (pci:00:01.0-3)
Found PCI device (pci:00:01.0-4)
Found PCI device (pci:00:01.0-5)
Device: pci:00:01.0-0
Control brightness has been discarded by the caps string.
Control contrast has been discarded by the caps string.
Control red has been discarded by the caps string.
Control green has been discarded by the caps string.
Control blue has been discarded by the caps string.
Control redblack has been discarded by the caps string.
Control greenblack has been discarded by the caps string.
Control blueblack has been discarded by the caps string.
Control colortemp has been discarded by the caps string.
Control hpos has been discarded by the caps string.
Control vpos has been discarded by the caps string.
Control hsize has been discarded by the caps string.
Control vsize has been discarded by the caps string.
Control auto has been discarded by the caps string.
Control hpincushion has been discarded by the caps string.
Control hpincushionbalance has been discarded by the caps string.
Control vlinearity has been discarded by the caps string.
Control vlinearitybalance has been discarded by the caps string.
Control hmisconvergence has been discarded by the caps string.
Control vmisconvergence has been discarded by the caps string.
Control keybalance has been discarded by the caps string.
Control key has been discarded by the caps string.
Control tdistortionctrl has been discarded by the caps string.
Control tdistortionbalance has been discarded by the caps string.
Control bdistortionctrl has been discarded by the caps string.
Control bdistortionbalance has been discarded by the caps string.
Control tilt has been discarded by the caps string.
Control hmoire has been discarded by the caps string.
Control vmoire has been discarded by the caps string.
Control focus has been discarded by the caps string.
Control coarse has been discarded by the caps string.
Control fine has been discarded by the caps string.
Control defaults has been discarded by the caps string.
Control defaultluma has been discarded by the caps string.
Control defaultgeom has been discarded by the caps string.
Control defaultcolor has been discarded by the caps string.
Control settings has been discarded by the caps string.
Control audiospeakervolume has been discarded by the caps string.
Control degauss has been discarded by the caps string.
Control osdorientation has been discarded by the caps string.
Control inputsource has been discarded by the caps string.
Control dpms has been discarded by the caps string.
Control power has been discarded by the caps string.
ddcci_open returned 0
Device: pci:00:01.0-1
ddcci_open returned -2
Device: pci:00:01.0-2
ddcci_open returned -2
Device: pci:00:01.0-3
ddcci_open returned -2
Device: pci:00:01.0-4
ddcci_open returned -2
Device: pci:00:01.0-5
ddcci_open returned -2
Detected monitors :
 - Device: pci:00:01.0-0
   DDC/CI supported: Yes
   Monitor Name: VESA standard monitor
   Input type: Analog
  (Automatically selected)
Reading EDID and initializing DDC/CI at bus pci:00:01.0-0...
Device: pci:00:01.0-0
Serial number: 16843009
Manufactured: Week 44, 2006
EDID version: 1.3
Maximum size: 38 x 30 (cm)
Control brightness has been discarded by the caps string.
Control contrast has been discarded by the caps string.
Control red has been discarded by the caps string.
Control green has been discarded by the caps string.
Control blue has been discarded by the caps string.
Control redblack has been discarded by the caps string.
Control greenblack has been discarded by the caps string.
Control blueblack has been discarded by the caps string.
Control colortemp has been discarded by the caps string.
Control hpos has been discarded by the caps string.
Control vpos has been discarded by the caps string.
Control hsize has been discarded by the caps string.
Control vsize has been discarded by the caps string.
Control auto has been discarded by the caps string.
Control hpincushion has been discarded by the caps string.
Control hpincusi810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
==>ddcpci is quitting.
hionbalance has been discarded by the caps string.
Control vlinearity has been discarded by the caps string.
Control vlinearitybalance has been discarded by the caps string.
Control hmisconvergence has been discarded by the caps string.
Control vmisconvergence has been discarded by the caps string.
Control keybalance has been discarded by the caps string.
Control key has been discarded by the caps string.
Control tdistortionctrl has been discarded by the caps string.
Control tdistortionbalance has been discarded by the caps string.
Control bdistortionctrl has been discarded by the caps string.
Control bdistortionbalance has been discarded by the caps string.
Control tilt has been discarded by the caps string.
Control hmoire has been discarded by the caps string.
Control vmoire has been discarded by the caps string.
Control focus has been discarded by the caps string.
Control coarse has been discarded by the caps string.
Control fine has been discarded by the caps string.
Control defaults has been discarded by the caps string.
Control defaultluma has been discarded by the caps string.
Control defaultgeom has been discarded by the caps string.
Control defaultcolor has been discarded by the caps string.
Control settings has been discarded by the caps string.
Control audiospeakervolume has been discarded by the caps string.
Control degauss has been discarded by the caps string.
Control osdorientation has been discarded by the caps string.
Control inputsource has been discarded by the caps string.
Control dpms has been discarded by the caps string.
Control power has been discarded by the caps string.

EDID readings:
	Plug and Play ID: HWP2692 [VESA standard monitor]
	Input type: Analog
=============================== WARNING ===============================
There is no support for your monitor in the database, but ddccontrol is
using a basic generic profile. Many controls will not be supported, and
some controls may not work as expected.
Please update ddccontrol-db, or, if you are already using the latest
version, please send the output of the following command to
ddccontrol-users@lists.sourceforge.net:

LANG= LC_ALL= ddccontrol -p -c -d

Thank you.
=============================== WARNING ===============================

Capabilities:
Raw output: prot(monitor)type(lcd)model(LP1965)cmds(01 02 03 07 0C 4E F3 E3)vcp(02 04 05 06 08 0E 0B 0C 10 12 14(01 05 08 0B) 16 18 1A 1E 1F 20 30 3E 60(03 04) 6C 6E 70 AE B6 C0 C6 C8 C9 CA D6(01 04) DF FA(00 01 02) FB FC FD FE(00 01 02 04))mswhql(1) mccs_ver(1.1) asset_eep(32) mpu_ver(01)
Parsed output: 
	VCP: 
	Type: Unknown

Controls (valid/current/max) [Description - Value name]:
Control 0x02: +/255/65535   [???]
Control 0x04: +/2/255   [???]
Control 0x05: +/2/255   [???]
Control 0x06: +/2/255   [???]
Control 0x08: +/2/255   [???]
Control 0x0b: +/50/65535   [???]
Control 0x0c: +/70/65535   [???]
Control 0x0e: +/50/100   [???]
Control 0x10: +/90/100   [???]
Control 0x12: +/80/100   [???]
Control 0x14: +/5/11   [???]
Control 0x16: +/255/255   [???]
Control 0x18: +/255/255   [???]
Control 0x1a: +/255/255   [???]
Control 0x1e: +/0/1   [???]
Control 0x1f: +/0/1   [???]
Control 0x20: +/137/319   [???]
Control 0x30: +/20/39   [???]
Control 0x3e: +/50/100   [???]
Control 0x60: +/1/3   [???]
Control 0x6c: +/127/255   [???]
Control 0x6e: +/127/255   [???]
Control 0x70: +/127/255   [???]
Control 0xac: +/43899/65535   [???]
Control 0xae: +/8500/65535   [???]
Control 0xb6: +/3/4   [???]
Control 0xc0: +/2661/65535   [???]
Control 0xc6: +/90/65535   [???]
Control 0xc8: +/34148/65535   [???]
Control 0xc9: +/3/65535   [???]
Control 0xca: +/2/255   [???]
Control 0xcc: +/3/10   [???]
Control 0xd6: +/1/4   [???]
Control 0xdf: +/512/65535   [???]
Control 0xfa: +/0/65535   [???]
Control 0xfb: +/101/65535   [???]
Control 0xfe: +/0/65535   [???]
ddcpci being released...
