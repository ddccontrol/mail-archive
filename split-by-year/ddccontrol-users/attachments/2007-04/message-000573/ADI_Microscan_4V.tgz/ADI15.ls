ddccontrol version 0.4.2
Copyright 2004-2005 Oleg I. Vdovikin (oleg@cs.msu.su)
Copyright 2004-2006 Nicolas Boichat (nicolas@boichat.ch)
This program comes with ABSOLUTELY NO WARRANTY.
You may redistribute copies of this program under the terms of the GNU General Public License.

ddcpci initing...
Starting /usr/local/bin/ddcpci 1 -1308278968 &...
Probing for available monitors...
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
i810_open: Using region 1 (f4000000, 80000)
==>ddcpci is quitting.
Found PCI device (pci:00:01.0-0)
Found PCI device (pci:00:01.0-1)
Found PCI device (pci:00:01.0-2)
Found PCI device (pci:00:01.0-3)
Found PCI device (pci:00:01.0-4)
Found PCI device (pci:00:01.0-5)
Device: pci:00:01.0-0
Control brightness has been discarded by the caps string.
Control contrast has been discarded by the caps string.
Control red has been discarded by the caps string.
Control green has been discarded by the caps string.
Control blue has been discarded by the caps string.
Control redblack has been discarded by the caps string.
Control greenblack has been discarded by the caps string.
Control blueblack has been discarded by the caps string.
Control colortemp has been discarded by the caps string.
Control hpos has been discarded by the caps string.
Control vpos has been discarded by the caps string.
Control hsize has been discarded by the caps string.
Control vsize has been discarded by the caps string.
Control auto has been discarded by the caps string.
Control hpincushion has been discarded by the caps string.
Control hpincushionbalance has been discarded by the caps string.
Control vlinearity has been discarded by the caps string.
Control vlinearitybalance has been discarded by the caps string.
Control hmisconvergence has been discarded by the caps string.
Control vmisconvergence has been discarded by the caps string.
Control keybalance has been discarded by the caps string.
Control key has been discarded by the caps string.
Control tdistortionctrl has been discarded by the caps string.
Control tdistortionbalance has been discarded by the caps string.
Control bdistortionctrl has been discarded by the caps string.
Control bdistortionbalance has been discarded by the caps string.
Control tilt has been discarded by the caps string.
Control hmoire has been discarded by the caps string.
Control vmoire has been discarded by the caps string.
Control focus has been discarded by the caps string.
Control coarse has been discarded by the caps string.
Control fine has been discarded by the caps string.
Control defaults has been discarded by the caps string.
Control defaultluma has been discarded by the caps string.
Control defaultgeom has been discarded by the caps string.
Control defaultcolor has been discarded by the caps string.
Control settings has been discarded by the caps string.
Control audiospeakervolume has been discarded by the caps string.
Control degauss has been discarded by the caps string.
Control osdorientation has been discarded by the caps string.
Control inputsource has been discarded by the caps string.
Control dpms has been discarded by the caps string.
Control power has been discarded by the caps string.
ddcci_open returned -1
Device: pci:00:01.0-1
ddcci_open returned -2
Device: pci:00:01.0-2
ddcci_open returned -2
Device: pci:00:01.0-3
ddcci_open returned -2
Device: pci:00:01.0-4
ddcci_open returned -2
Device: pci:00:01.0-5
ddcci_open returned -2
Detected monitors :
 - Device: pci:00:01.0-0
   DDC/CI supported: No
   Monitor Name: VESA standard monitor
   Input type: Analog
ddcpci being released...
